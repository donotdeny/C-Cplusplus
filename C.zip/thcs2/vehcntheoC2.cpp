#include<stdio.h>

int main()
{
	int a, b;
	scanf("%d%d", &a, &b);
	if(a<=b){
	for(int i=1;i<=a;i++){
		int t=i;
		int k=b;
		for(int j=1;j<=b;j++){
			if(t<b){
				printf("%d", t);
				t++;
			}
			else {
				printf("%d", k);
				k--;
			}
		}printf("\n");
	}
    }
    else {
    	for(int i=1;i<=a;i++){
    		int t=i;
    		int k=b;
    		for(int j=1;j<=b;j++){
    			if(i<b){
    				if(t<b){
				        printf("%d", t);
				        t++;
			        }
			        else {
				        printf("%d", k);
				        k--;
				    }
			}
			    else {
			    	printf("%d", t);
			    	t--;
				}
		}printf("\n");
	}
}

return 0;
}

