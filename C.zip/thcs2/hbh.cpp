#include<stdio.h>
/*

~~~~*****
~~~*****
~~*****
~*****
*****

*/
int main()
{
	int n;
	scanf("%d", &n);
	for(int i=1;i<=n;i++){
		for(int j=1;j<2*n;j++){
			if(j<=n-i) printf("~");
			if(n-i<j) printf("*");
			if(j>=2*n-i) printf(" ");
		}
		printf("\n");
	}


return 0;
}

