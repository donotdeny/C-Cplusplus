#include<stdio.h>

int main()
{
	int a, b;
	scanf("%d %d", &a, &b);
	if(a>=b){
		int k=a;
	for(int i=1;i<=a;i++){
		int l=k;
		int t=1;
		for(int j=1;j<=b;j++){
			if(l==1){
				printf("%d", t);
				t++;
			}
			else{ printf("%d", l);
			       l--;
				   }
		}
		k--;
		printf("\n");
	}
    }
    else {
    	int k=b;
	for(int i=1;i<=a;i++){
		int l=k;
		int t=1;
		for(int j=1;j<=b;j++){
			if(l==1){
				printf("%d", t);
				t++;
			}
			else{ printf("%d", l);
			       l--;
				   }
		}
		k--;
		printf("\n");
	}
	}

return 0;
}

