#include<stdio.h>

int main()
{
	int n;
	scanf("%d", &n);
	int m=n, tg=0;
	while(n>0){
		tg=tg*10+n%10;
		n/=10;
	}if(tg==m) printf("1");
	else printf("0");

return 0;
}

