#include<iostream>
using namespace std;

bool isNumber(char s)
{
	if(s>=48&&s<=57) return true;
	return false;
}

int main()
{
	int a;
	cin >> a;
	if(isNumber(a)) cout << "1";
	

return 0;
}

