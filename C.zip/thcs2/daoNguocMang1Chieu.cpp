#include<stdio.h>
#define MAX 100

void nhapMang(int a[], int n)
{
	for(int i=0;i<n;i++){
		scanf("%d", &a[i]);
	}
}

void swap(int &a, int &b)
{
	int temp=a;
	a=b;
	b=temp;
}

void daoNguoc(int a[], int n)
{
	for(int i=0,j=n-1;j>=i;i++,j--){
		swap(a[i],a[j]);
	}
}

void xuatMang(int a[], int n)
{
	for(int i=0;i<n;i++){
		printf("%d ", a[i]);
	}
}

int main()
{
	int n, a[MAX];
	scanf("%d", &n);
	nhapMang(a,n);
	daoNguoc(a,n);
	xuatMang(a,n);
	
return 0;
}

