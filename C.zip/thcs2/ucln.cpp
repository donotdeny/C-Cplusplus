#include<stdio.h>

int main()
{
	int a, b;
	scanf("%d %d", &a, &b);
	while(a!=b){
		if(a>b) a-=b;
		else if(a<b) b-=a; 
	}
	printf("%d", a);
return 0;
}

