#include<stdio.h>
#include<stdbool.h>

bool thuanNghich(int n)
{
	int temp=n;
	int tg=0;
	while(n>0){
		tg=tg*10+n%10;
		n/=10;
	}
	if(temp==tg) return true;
	return false;
}

bool notNine(int n)
{
	int temp=0;
	while(n>0){
		temp=n%10;
		if(temp==9) return false;
		n/=10;
	}
	return true;
}

int main()
{
	int n;
	scanf("%d", &n);
	for(int i=2;i<n;i++){
		if(thuanNghich(i)&&notNine(i)) printf("%d ", i);
	}

return 0;
}

