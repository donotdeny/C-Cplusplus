#include<stdio.h>
#include<stdbool.h>

int giaiThua(int n)
{
	int gt=1;
	for(int i=1;i<=n;i++){
		gt*=i;
	}
	return gt;
}

bool strongNum(int n)
{
	int t=n, tg;
	int sum=0;
	while(n>0){
		tg=n%10;
		sum+=giaiThua(tg);
		n/=10;
	} if(t==sum) return true;
	return false;
}

int main()
{
	int n;
	scanf("%d", &n);
	for(int i=1;i<=n;i++){
		if(strongNum(i)) printf("%d ", i);
	}

return 0;
}

