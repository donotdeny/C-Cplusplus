#include<stdio.h>

void nhap(int a[], int n)
{
	for(int i=0;i<n;i++){
		scanf("%d", &a[i]);
	}
}
int binarySearch(int a[], int n, int b)
{
	int left=0, right=n-1;
	while(left<=right){
		int mid=(left+right)/2;
		if(a[mid]==b) return 1;
		else {
			if(a[mid]<b) left=mid+1;
			else right=mid-1;
		}
	}
	return 0;
}

int main()
{
	int a[50];
	int n,b;
	scanf("%d", &n);
	nhap(a,n);
	scanf("%d", &b);
	printf("%d", binarySearch(a,n,b));

return 0;
}

