#include<stdio.h>
#define MAX 100

void nhapMang(int a[][MAX], int m, int n)
{
	for(int i=0;i<m;i++){
		for(int j=0;j<n;j++){
			scanf("%d", &a[i][j]);
		}
	}
}

void xuLy(int a[][MAX], int b[][MAX], int c[][MAX], int m, int n)
{
	for(int i=0;i<m;i++){
		for(int j=0;j<m;j++){
			for(int l=0;l<n;l++){
				c[i][j]+=a[i][l]*b[l][j];
			}
		}
	}
}

void xuatMang(int a[][MAX], int m)
{
	for(int i=0;i<m;i++){
		for(int j=0;j<m;j++){
			printf("%d ", a[i][j]);
		}printf("\n");
	}
}

int main()
{
	int a[MAX][MAX], b[MAX][MAX], c[MAX][MAX];
	int m, n;
	scanf("%d%d", &m, &n);
	nhapMang(a,m,n);
	nhapMang(b,n,m);
	xuLy(a,b,c,m,n);
	xuatMang(c,m);

return 0;
}

