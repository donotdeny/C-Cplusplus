#include<stdio.h>

int main()
{
	int n, tg=1, i;
	scanf("%d", &n);
	while(n>0){
		i=n%10;
		tg*=i;
		n/=10;
	}printf("%d", tg);

return 0;
}

