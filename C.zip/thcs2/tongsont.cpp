#include<stdio.h>
#include<stdbool.h>

bool soNguyenTo(int n)
{
	int count=0;
	for(int i=1;i<=n;i++){
		if(n%i==0) count++;
	}if(count==2) return true;
	return false;
}

int main()
{
	int a, b;
	scanf("%d %d", &a, &b);
	int sum=0;
	if(a<b){
		for(int i=a;i<=b;i++){
			if(soNguyenTo(i)) sum+=i;
		} printf("%d", sum);
	}
	else {
		if(a>b){
			for(int i=b;i<=a;i++){
				if(soNguyenTo(i)) sum+=i;
			}
		}printf("%d", sum);
	}	
	
return 0;
}

