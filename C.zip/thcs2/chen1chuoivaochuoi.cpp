#include<stdio.h>
#include<string.h>

int main()
{
	char str1[100], str2[100];
	int len1, len2, p;
	fgets(str1, 99, stdin);
	fgets(str2, 99, stdin);
	scanf("%d", &p);
	p--;
	len1=strlen(str1)-1;
	len2=strlen(str2)-1;
	len1+=len2;
	for(int i=len1;i>=p;i--){
		str1[i]=str1[i-len2];
	}
	for(int i=p, j=0;i<len1-len2, j<len2;i++,j++){
		str1[i]=str2[j];
	}
	for(int i=0;i<len1;i++){
		printf("%c", str1[i]);
	}


return 0;
}

