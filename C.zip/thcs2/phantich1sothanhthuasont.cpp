#include<stdio.h>
#include<math.h>
#include<stdbool.h>

bool primeNum(int n)
{
	int count=0;
	for(int i=2;i<=n;i++){
		if(n%i==0) count++;
	} if(count==1) return true;
	return false;
}

bool soTang(int n)
{
	int temp1, temp2;
	while(n>0){
		temp1=n%10;
		n/=10;
		temp2=n%10;
		if(temp1<temp2) return false;	
	}
	return true;
}

bool soGiam(int n)
{
	int temp1, temp2;
	while(n>0){
		temp1=n%10;
		n/=10;
		temp2=n%10;
		if(temp1>temp2) return false;
	}
	return true;
}

int main()
{
	int n;
	int count=0;
	scanf("%d", &n);
	for(int i=1;i<pow(10,n);i++){
		if(primeNum(i)&&soTang(i)) printf("%d ", i);
//		if(primeNum(i)&&soGiam(i)) printf("%d ", i);
	}

return 0;
}

