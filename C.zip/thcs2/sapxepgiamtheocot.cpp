#include<stdio.h>

void nhapMang(int a[][50], int n)
{
	for(int i=0;i<n;i++){
		for(int j=0;j<n;j++){
			scanf("%d", &a[i][j]);
		}
	}
}

void swap(int &a, int &b)
{
	int tg=a;
	a=b;
	b=tg;
}

void xuLy(int a[][50], int n)
{
	for(int j=0;j<n;j++){
		for(int i=0;i<n-1;i++){
			for(int k=i+1;k<n;k++){
				if(a[i][j]<a[k][j]) swap(a[i][j],a[k][j]);
			}
		}
	}
}

void xuatMang(int a[][50], int n)
{
	for(int i=0;i<n;i++){
		for(int j=0;j<n;j++){
			printf("%d ", a[i][j]);
		}printf("\n");
	}
}

int main()
{
	int a[50][50];
	int n;
	scanf("%d", &n);
	nhapMang(a,n);
	xuLy(a,n);
	xuatMang(a,n);

return 0;
}

