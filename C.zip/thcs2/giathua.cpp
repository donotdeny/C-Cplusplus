#include<stdio.h>

int main()
{
	int n;
	unsigned long long gt=1;
	scanf("%d", &n);
	if(n<0) printf("0");
	else {
	for(int i=1;i<=n;i++){
		gt*=i;
	}
	printf("%lld", gt);
    }

return 0;
}

