#include<stdio.h>
#include<string.h>

int main()
{
	int a[20];
	char s[100];
	char temp[10];
	int i, j=0, l, count=0, size;
	fgets(s, sizeof s, stdin);
	for(i=0;i<strlen(s)-1;i++){
		if(s[i]==' '&&s[i+1]!=' '){
			a[j]=i;
			j++;
			count++;
		}
	}
	for(i=0;i<count;i++){
		size=0;
		for(j=a[i]+1,l=0;j<strlen(s)-1;j++,l++){
			if(s[j]==' ') break;
			size++;
		}
		for(j=a[i]+1,l=0;l<size;j++,l++){
			if(s[j]==' ') break;
			temp[l]=s[j];
		}
		for(l=0;;l++){
			if(l==size){
				temp[l]=NULL;
				break;
			}
		}
		puts(temp);
	}

return 0;
}

