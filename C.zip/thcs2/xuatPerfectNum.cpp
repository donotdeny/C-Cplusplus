#include<stdio.h>
#include<stdbool.h>

bool perfectNum(int n)
{
	int sum=0;
	for(int i=1;i<n;i++){
		if(n%i==0) sum+=i;
	}if(sum==n) return true;
	return false;
}

int main()
{
	int a, b;
	scanf("%d %d", &a, &b);
	if(a<b) {
			for(int i=a;i<=b;i++){
				if(perfectNum(i)) printf("%d ", i);
			}
		}
	else {
			for(int i=b;i<=a;i++){
				if(perfectNum(i)) printf("%d ", i);
			}
		}


return 0;
}

