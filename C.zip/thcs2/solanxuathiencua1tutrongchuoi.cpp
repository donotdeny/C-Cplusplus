#include<stdio.h>
#include<stdlib.h>
#include<string.h>

int count(char *s)
{
	int count=0;
	if(s[0]!=' ') count=1;
	for(int i=0;i<strlen(s)-1;i++){
		if(s[i]==' '&&s[i+1]!=' ') count++;
	}
	return count;
}

typedef struct{
	char str[100];
}string;

int main()
{
	char str[100];
	fgets(str, 99, stdin);
	strlwr(str);
	char *p=strchr(str, '\n');
	if(p!=NULL) *p='\0';
	int n=count(str);
	string *word;
	word=(string*)malloc(n*sizeof(string));
	int i=0;
	char *token;
	token=strtok(str," ");
	while(token!=NULL){
		strcpy(word[i].str,token);
		token=strtok(NULL, " ");
		i++;
	}
	int dem=0;
	for(i=0;i<n;i++){
		if(strcmp(word[0].str,word[i].str)==0) dem++;
	}
	printf("%s %d\n", word[0].str, dem);
	for(i=1;i<n-1;i++){
		dem=0;
		int k=0;
		for(int j=0;j<i;j++){
			if(strcmp(word[i].str,word[j].str)==0) k=1;
		}
		if(k==1) continue;
		else{
			for(int l=0;l<n;l++){
				if(strcmp(word[i].str,word[l].str)==0) dem++;
			}
			printf("%s %d\n", word[i].str, dem);
		}
	}

return 0;
}

