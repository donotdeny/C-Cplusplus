#include<stdio.h>

int abs(int a, int b)
{
	if(a>b) return a-b;
	return b-a;
}

void sapXep(int a[], int n)
{
	for(int i=0;i<n-1;i++){
		for(int j=i+1;j<n;j++){
			if(a[i]>a[j]){
				int temp=a[i];
				a[i]=a[j];
				a[j]=temp;
			}
		}
	}
}

int main()
{
	int a[50];
	int n, min=9999, s=9999, temp;
	scanf("%d", &n);
	for(int i=0;i<n;i++){
		scanf("%d", &a[i]);
	}
	sapXep(a,n);
	for(int i=0;i<n-1;i++){
		if(min>abs(a[i],a[i+1])) min=abs(a[i],a[i+1]);
	}
	printf("%d ", min);
	for(int i=0;i<n-1;i++){
		if(s>abs(a[i],a[i+1])) s=abs(a[i],a[i+1]);
		if(s==min){
			temp=i;
			break;
		}
	}
	printf("%d %d", a[temp], a[temp+1]);

return 0;
}

