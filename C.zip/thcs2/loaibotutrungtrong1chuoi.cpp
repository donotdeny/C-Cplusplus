#include<stdio.h>
#include<string.h>
#include<stdlib.h>

int dem(char *s)
{
	int count=0;
	if(s[0]!=' ') count=1;
	for(int i=0;i<strlen(s)-1;i++){
		if(s[i]==' '&&s[i+1!=' ']) count++;
	}
	return count;
}

typedef struct{
	char str[100];
}string;

int main()
{
	int max=0;
	char str[100];
	fgets(str, 99, stdin);
	strlwr(str);
	char *p=strchr(str,'\n');
	if(p!=NULL) *p='\0';
	string *word;
	int n=dem(str), i=0;
	word=(string*)malloc(n*sizeof(string));
	char *token, *token1, *token2;
	token=strtok(str," ");
	while(token!=NULL){
		strcpy(word[i].str,token);
		token=strtok(NULL, " ");
		i++;
	}
	printf("%s ", word[0].str);
	for(int i=1;i<n;i++){
		int k=0;
		for(int j=0;j<i;j++){
			if(strcmp(word[i].str,word[j].str)==0) k=1;
		}
		if(k!=1) printf("%s ", word[i]);
	}

return 0;
}

