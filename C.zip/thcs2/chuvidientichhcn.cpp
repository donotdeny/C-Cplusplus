#include<stdio.h>

int main()
{
	int a, b, s, c;
	scanf("%d %d", &a, &b);
	if(a<=0||b<=0) printf("0");
	else {s=a*b;
	     c=(a+b)*2;
	     printf("%d %d", c, s);
        }    

return 0;
}

