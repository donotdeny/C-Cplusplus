#include<stdio.h>
#include<math.h>
#include<stdbool.h>

bool chiaHet(int n){
	int sum=0;
	int i;
	while(n>0){
		i=n%10;
		sum+=i;
		n/=10;
	} if(sum%10==0) return true;
	return false;
}
bool thuanNghich(int n){
	int tg=0;
	int m=n;
	while(n>0){
		tg=tg*10+n%10;
		n/=10;
	} if(tg==m) return true;
	return false;
}

int main()
{
	int n, count=0;
	scanf("%d", &n);
	int t=pow(10,n);
	int u=pow(10,n-1);
	for(int i=u;i<t;i++){
		if(thuanNghich(i)&&chiaHet(i)) count++;
	}
	printf("%d", count);
	
return 0;
}

