#include<stdio.h>
#include<string.h>
#include<stdlib.h>

int dem(char *s)
{
	int count=0;
	if(s[0]!=' ') count=1;
	for(int i=0;i<strlen(s)-1;i++){
		if(s[i]==' '&&s[i+1!=' ']) count++;
	}
	return count;
}

typedef struct{
	char str[100];
}string;

int main()
{
	int max=0;
	char str[100];
	char str2[100];
	fgets(str, 99, stdin);
	fgets(str2, 99, stdin);
	strlwr(str);
	char *p=strchr(str,'\n');
	if(p!=NULL) *p='\0';
	char *p1=strchr(str2,'\n');
	if(p1!=NULL) *p1='\0';
	string *word, *word2, *temp;
	int n=dem(str), i=0;
	int n2=dem(str2);
	word=(string*)malloc(n*sizeof(string));
	word2=(string*)malloc(n2*sizeof(string));
	temp=(string*)malloc(20*sizeof(string));
	char *token, *token1;
	token=strtok(str," ");
	while(token!=NULL){
		strcpy(word[i].str,token);
		token=strtok(NULL, " ");
		i++;
	}
	i=0;
	token1=strtok(str2," ");
	while(token1!=NULL){
		strcpy(word2[i].str,token1);
		token1=strtok(NULL, " ");
		i++;
	}
	int t=0, b=0;
	for(int j=0;j<n2;j++){
		if(strcmp(word[0].str,word2[j].str)==0) t=1;
	}
	if(t!=1){	
		strcpy(temp[0].str,word[0].str);
		b++;
    }
	for(i=1;i<n;i++){
		int k=0;
		int l=0;
		for(int j=0;j<n2;j++){
			if(strcmp(word[i].str,word2[j].str)==0) k=1;
		}
		for(int a=0;a<i;a++){
			if(strcmp(word[i].str,word[a].str)==0) l=1;
		}
		if(k!=1&&l!=1){
			strcpy(temp[b].str,word[i].str);
			b++;
		}
	}
	int arr[20];
	for(i=0;i<b;i++){
		arr[i]=i;
	}
	for(i=0;i<b-1;i++){
		for(int j=i+1;j<b;j++){
			if(temp[arr[i]].str[0]>temp[arr[j]].str[0]){
				int tmp=arr[i];
				arr[i]=arr[j];
				arr[j]=tmp;
			}
		}
	}
	for(i=0;i<b;i++){
		printf("%s ", temp[arr[i]].str);
	}
	
return 0;
}

