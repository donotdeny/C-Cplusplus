#include<stdio.h>

void nhapMang(int arr[], int LENGTH)
{
	for(int i=0;i<LENGTH;i++){
		scanf("%d", &arr[i]);
	}
}
void xuatMang(int arr[], int LENGTH)
{
	for(int i=0;i<LENGTH;i++){
		printf("%d ", arr[i]);
	}
}
void bubblesoft(int arr[], int LENGTH)
{
	for(int i=0;i<LENGTH-1;i++){
		for(int j=LENGTH-1;j>i;j--){
			if(arr[j]<arr[j-1]){
				int tg=arr[j];
				arr[j]=arr[j-1];
				arr[j-1]=tg;
			}
		}
	}
}

int main()
{
	int LENGTH;
	scanf("%d", &LENGTH);
	int arr[LENGTH];
	nhapMang(arr,LENGTH);
	xuatMang(arr,LENGTH);
	printf("\n");
	bubblesoft(arr,LENGTH);
	xuatMang(arr,LENGTH);
	

return 0;
}

