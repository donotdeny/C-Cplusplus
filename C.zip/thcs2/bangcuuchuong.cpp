#include<stdio.h>

int main()
{
	int n, i=1;
	scanf("%d", &n);
	int u=n;
	int lim=10*n;
	while(n<lim){
		n=u;
		n*=i;
		printf("%d ", n);
		i++;	
	}

return 0;
}

