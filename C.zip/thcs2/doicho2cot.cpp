#include<stdio.h>

void nhapMang(int arr[][50], int m, int n)
{
	for(int i=0;i<m;i++){
		for(int j=0;j<n;j++){
			scanf("%d", &arr[i][j]);
		}
	}
}

void swap(int &a, int &b)
{
	int tg=a;
	a=b;
	b=tg;
}

void xuatMang(int arr[][50], int m, int n)
{
	for(int i=0;i<m;i++){
		for(int j=0;j<n;j++){
			printf("%d ", arr[i][j]);
		}printf("\n");
	}
}

int main()
{
	int arr[50][50];
	int m, n, a, b;
	scanf("%d%d", &m, &n);
	nhapMang(arr,m,n);
	scanf("%d%d", &a, &b);
	int x=a-1, y=b-1;
	if(m>n){
		for(int i=0;i<m;i++){
		swap(arr[i][x],arr[i][y]);
	}
	}
	else {
  	for(int i=0;i<n;i++){
		swap(arr[i][x],arr[i][y]);
	}
    }
	xuatMang(arr,m,n);

return 0;
}

