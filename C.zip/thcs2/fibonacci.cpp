#include<stdio.h>
#include<stdbool.h>

bool primeNum(int n)
{
	int count=0;
	for(int i=2;i<=n;i++){
		if(n%i==0) count++;
	}if(count==1) return true;
	return false;
}

int fb(int n)
{
    if(n==1||n==0||n==2||n==3) return n;
   return fb(n-2)+fb(n-1);
}

bool dependOfFibo(int n)
{
	for(int i=0;;i++){
		if(fb(i)==n) return true;
		else if(fb(i)>n) break;
	}
	return false;
}

int sum(int n)
{
	int tong=0;
	while(n>0){
		tong+=n%10;
		n/=10;
	}
	return tong;
}



int main()
{
	int a, b;
	scanf("%d%d", &a, &b);
	if(a<b){
		for(int i=a;i<=b;i++){
			int t=sum(i);
			if(primeNum(i)&&dependOfFibo(t)) printf("%d ", i);
		}
	}
	if(a>b){
		for(int i=b;i<=a;i++){
			int t=sum(i);
			if(primeNum(i)&&dependOfFibo(t)) printf("%d ", i);
		}
	}
	

return 0;
}

