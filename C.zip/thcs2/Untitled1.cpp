#include<iostream>
#include<cstring>
#include<cmath>
using namespace std;

bool isNumber(char s)
{
	if(s>=48&&s<=57) return true;
	return false;
}

int main()
{
	int t;
	cin >> t;
	cin.ignore();
	while(t--){
		long long sum=0;
		char str[1000];
		cin.getline(str, 999);
		for(int i=0;i<strlen(str);i++){
			int dem=0;
			if(isNumber[i-1]) continue;
			for(int j=i;j<strlen(str);j++){
				if(!isNumber(str[j])) break;
				else dem++;
			}
			int temp = dem;
			for(int j=i;j<strlen(str);j++){
				if(!isNumber(str[j])) break;
				else {
					sum += (str[j]-'0')*pow(10, temp-1);
					temp--;
				}
			}
		}
		cout << sum << endl;
	}

return 0;
}

