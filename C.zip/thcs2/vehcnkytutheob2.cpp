#include<stdio.h>
#define MAX 50

int main()
{
	int arr[MAX][MAX];
	int a, b;
	scanf("%d%d", &a, &b);
	int t=65;
	int c=t+b-1;
	for(int i=0;i<a;i++){
		int k=65+i;
		for(int j=0;j<b;j++){
			if(j>=b-i) arr[i][j]=c;
			else {
				arr[i][j]=k;
				k++;
			}
		}
		t++;
	}
	for(int i=a-1;i>=0;i--){
		for(int j=0;j<b;j++){
			printf("%c", arr[i][j]);
		}printf("\n");
	}

return 0;
}

