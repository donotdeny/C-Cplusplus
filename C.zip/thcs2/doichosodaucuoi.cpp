#include<stdio.h>

int main()
{
	int n, d;
	scanf("%d", &n);
	int c=n%10;
	while(n>0){
		d=n%10;
		n/=10;
	} printf("%d %d", c, d);

return 0;
}

