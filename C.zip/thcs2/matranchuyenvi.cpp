#include<stdio.h>
#define MAX 100

void nhapMang(int a[][MAX], int n)
{
	for(int i=0;i<n;i++){
		for(int j=0;j<n;j++){
			scanf("%d", &a[i][j]);
		}
	}
}

void xuatMang(int a[][MAX], int n)
{
	for(int i=0;i<n;i++){
		for(int j=0;j<n;j++){
			printf("%d ", a[i][j]);
		}printf("\n");
	}
}

int main()
{
	int a[MAX][MAX];
	int n;
	scanf("%d", &n);
	nhapMang(a,n);
	for(int i=0;i<n;i++){
		for(int j=0;j<i;j++){
			int tg=a[i][j];
			a[i][j]=a[j][i];
			a[j][i]=tg;;
		}
	}
	xuatMang(a,n);

return 0;
}

