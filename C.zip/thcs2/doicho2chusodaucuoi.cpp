#include<stdio.h>

int soPhanTu(int n)
{
	int count=0;
	while(n>0){
		count++;
		n/=10;
	}
	return count;
}

void nhapMang(int a[], int x, int n)
{
	int i=0;
	while(n>0){
		a[i]=n%10;
		n/=10;
		i++;
	}
}

void swap(int &a, int &b)
{
	int tg=a;
	a=b;
	b=tg;
}

void daoNguoc(int a[], int x)
{
	for(int i=0,j=x-1;i<=j;i++,j--){
		swap(a[i],a[j]);
	}
}

void inKq(int a[], int x)
{
	swap(a[0],a[x-1]);
	if(a[0]==0) {
		for(int i=0;i<x;i++){
			a[i]=a[i+1];
		}
		x--;
	}
	for(int i=0;i<x;i++){
		printf("%d", a[i]);
	}
}

int main()
{
	int n;
	scanf("%d", &n);
	int x=soPhanTu(n);
	int a[x];
	nhapMang(a,x,n);
	daoNguoc(a,x);
	inKq(a,x);

return 0;
}

