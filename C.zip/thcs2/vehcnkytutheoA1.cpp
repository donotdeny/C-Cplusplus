#include<stdio.h>

int main()
{
	int a, b;
	scanf("%d%d", &a, &b);
	if(a<=b){
		for(int i=1;i<=a;i++){
			int t=96+b;
			int k=t;
		    for(int j=1;j<=b;j++){
			    if(j>=i) printf("%c", t+1-i);
			    else {
					printf("%c", k);
			        k--;
				    }
			    }printf("\n");
		    }
	}  
	else {
		for(int i=1;i<=a;i++){
			int t=96+a;
			int k=t;
		    for(int j=1;j<=b;j++){
			    if(j>=i) printf("%c", t+1-i);
			    else {
			        printf("%c", k);
			        k--;
				}
			    }printf("\n");
		    }
	}
	

return 0;
}

