#include<stdio.h>
#include<string.h>
#include<stdbool.h>

bool isSpace(char c)
{
	return c==' '|| c=='\n'|| c=='	';
}

void removeAtTail(char* line)
{
	int len=strlen(line);
	int i=len-1;
	while(isSpace(line[i])){
		line[i]='\0';
		i--;
	}
}

void removeAtHead(char* c)
{
	int len=strlen(c);
	int count=0;
	for(int i=0;i<len;i++){
		if(isSpace(c[i])) count++;
		else break;
	}
	for(int i=0;i<=len-count;i++){
		c[i]=c[i+count];
	}
}

void removeAtMid(char* c)
{
	int len=strlen(c);
	for(int i=0;i<len;i++){
		if(isSpace(c[i])&&isSpace(c[i+1])){
			for(int j=i+1;j<len;j++){
				c[j]=c[j+1];
			}
			i--;
			len--;
		}
	}
}

int main()
{
	char line[50];
	int count=1, dem=1;
	int count1=1;
	int temp=0;
	fgets(line, sizeof line, stdin);
	removeAtTail(line);
	removeAtHead(line);
	removeAtMid(line);
	strlwr(line);
	for(int i=0;i<strlen(line);i++){
		if(isSpace(line[i])&&!isSpace(line[i+1])) count++;
	}
	for(int i=0;i<strlen(line);i++){
		if(isSpace(line[i])&&!isSpace(line[i+1])) dem++;
		if(dem==count){
			temp=i;
			break;
		}
	}
	for(int i=temp+1;i<strlen(line);i++){
		printf("%c", line[i]);
	}
	printf("%c", line[0]);
	for(int i=0;i<strlen(line);i++){
		if(isSpace(line[i])&&!isSpace(line[i+1])){
			count1++;
			if(count1>=count) break;
			printf("%c", line[i+1]);
		}
	}
	printf("@ptit.edu.vn");
	

return 0;
}

