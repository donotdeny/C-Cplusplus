#include<stdio.h>

int main()
{
	unsigned int n;
	printf("nhap n>0\n");
	scanf("%d", &n);
	unsigned int m=n;
	int tg=0;
	while(n>0){
		tg=tg*10+n%10;
		n/=10;
	}if(m==tg) printf("la so thuan nghich");
	else printf("ko la so thuan nghich");
		
return 0;
}

