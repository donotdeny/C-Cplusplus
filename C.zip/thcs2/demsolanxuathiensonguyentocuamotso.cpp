#include<stdio.h>
#include<stdbool.h>

int demSo(int n)
{
	int count=0;
	while(n>0){
		count++;
		n/=10;
	}
	return count;
}

bool primeNum(int n)
{
	int count=0;
	for(int i=2;i<=n;i++){
		if(n%i==0) count++;
	}
	if(count==1) return true;
	return false;
}

void nhapMang(int a[], int x, int n)
{
	int i=0;
	while(n>0){
		a[i]=n%10;
		n/=10;
		i++;
	}
}

void swap(int &a, int &b)
{
	int tg=a;
	a=b;
	b=tg;
}

void daoNguoc(int a[], int x)
{
	for(int i=0, j=x-1;i<=j;i++,j--){
		swap(a[i],a[j]);
	}
}

void xuatMang(int a[], int x)
{
	for(int i=0;i<x;i++){
		printf("%d ", a[i]);
	}
}

void xuatKq(int a[], int x)
{
	if(primeNum(a[0])) {
		int count=1;
		printf("%d ", a[0]);
		for(int i=1;i<x;i++){
			if(a[i]==a[0]) count++;
		}
		printf("%d\n", count);
	}
	for(int i=1;i<x;i++){
		if(!primeNum(a[i])) continue;
		int k=0;
		for(int j=0;j<i;j++){
			if(a[i]==a[j]) k=1;
		}
		if(k==1) continue;
		else {
			printf("%d ", a[i]);
			int count=0;
			for(int j=0;j<x;j++){
				if(a[i]==a[j]) count++;
			}
			printf("%d\n", count);
		}
	}
}

int main()
{
	int n;
	scanf("%d", &n);
	int x=demSo(n);
	int a[x];
	nhapMang(a,x,n);
	daoNguoc(a,x);
	xuatKq(a,x);

return 0;
}

