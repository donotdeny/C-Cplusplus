#include<stdio.h>

int main()
{
	int a, b;
	scanf("%d %d", &a, &b);
	int bcnn=a*b;
	while(a!=b){
		if(a>b) a-=b;
		else if(a<b) b-=a; 
	}
	printf("%d", bcnn/a);
return 0;
}

