#include<stdio.h>

int main()
{
	int a, b;
	scanf("%d %d", &a, &b);
	int max=a;
	if(max<b) max=b;
	printf("%d", max);

return 0;
}

