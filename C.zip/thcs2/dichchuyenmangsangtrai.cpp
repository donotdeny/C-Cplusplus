#include<stdio.h>

void nhapMang(int a[], int n)
{
	for(int i=0;i<n;i++){
		scanf("%d", &a[i]);
	}
}

void xuatMang(int a[], int n)
{
	for(int i=0;i<n;i++){
		printf("%d ", a[i]);
	}
}

void xuLy(int a[], int n, int x)
{
	for(int i=0;i<x;i++){ // x lan dich chuyen sang trai 1 don vi
		int first=a[0]; // luu lai gia tri a[0]
		for(int j=0;j<n;j++){
			a[j]=a[j+1];  // dich chuyen sang ben trai 1 don vi
		}
		a[n-1]=first;
	}
}

int main()
{
	int n, x;
	scanf("%d", &n);
	int a[n];
	nhapMang(a,n);
	scanf("%d", &x);
	xuLy(a,n,x);
	xuatMang(a,n);

return 0;
}

