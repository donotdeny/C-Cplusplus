#include<stdio.h>

int main()
{
	int n, i, count1=0, count2=0;
	scanf("%d", &n);
	if(n<0) printf("0");
	else{  if(n==0) printf("0 1");
	        else{
	      	while(n>0){
	      		i=n%10;
	      		if(n%2==0) count2++;
	      		else count1++;
	      		n/=10;
			  }
			  printf("%d %d", count1, count2);
		  }	  
}

return 0;
}

