#include<string.h>
#include<stdio.h>
#include<stdbool.h>
#include<ctype.h>

bool isCapital(char *c)
{
	for(int i=0;i<strlen(c);i++){
		if(islower(c[i])) return false;
	}
	return true;
}

int main()
{
   char str[80];
   const char s[2] = " ";
   char *token;
   gets(str);
   token = strtok(str, s);
   while( token != NULL ) 
   {
      if(isCapital(token)) printf("%s ", token);
      token = strtok(NULL, s);
   }
   
   return(0);
}

