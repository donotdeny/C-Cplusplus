#include<stdio.h>

int main()
{
	int a[50][50];
	int m, n;
	scanf("%d%d", &m, &n);
	for(int i=0;i<m;i++){
		for(int j=0;j<n;j++){
			scanf("%d", &a[i][j]);
		}
	}
	int max=-9999, max2=-9999;
	int temp1, temp2;
	for(int i=0;i<m;i++){
		int sum=0;
		for(int j=0;j<n;j++){
			sum+=a[i][j];
		}
		if(max<sum){
			max=sum;
			temp1=i;
		}
	}
	for(int i=0;i<n;i++){
		int sum=0;
		for(int j=0;j<m;j++){
			sum+=a[j][i];
		}
		if(max2<sum){
			max2=sum;
			temp2=i;
		}
	}
	for(int i=0;i<m;i++){
		for(int j=0;j<n;j++){
			if(i==temp1||j==temp2) continue;
			else printf("%d ", a[i][j]);
		}if(i!=temp1) printf("\n");
	}

return 0;
}

