#include<stdio.h>

int main()
{
	int a, b;
	scanf("%d%d", &a, &b);
	for(int i=1;i<=a;i++){
		int t=i;
		int k=i-1;
		int l=b-1;
		for(int j=1;j<=b;j++){
			if(i<=b){
			    if(j<=b+1-i){
				    printf("%d", t);
				    t++;
			    }
			    else{
				    printf("%d", k);
				    k--;
			    }
			}
			else {
				if(j==1){
					printf("%d", t);
				}
				else {
					printf("%d", l);
					l--;
				}
			}
		}
		printf("\n");
	}
	

return 0;
}

