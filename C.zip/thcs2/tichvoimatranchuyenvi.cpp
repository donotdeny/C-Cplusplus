#include<stdio.h>

void nhapMang(int a[][50], int m, int n)
{
	for(int i=0;i<m;i++){
		for(int j=0;j<n;j++){
			scanf("%d", &a[i][j]);
		}
	}
}


void chuyenVi(int a[][50], int b[][50], int m, int n, int x, int y)
{
	for(int i=0;i<x;i++){
		for(int j=0;j<y;j++){
			int tg=b[i][j];
			b[i][j]=a[j][i];
			a[j][i]=tg;
		}
	}
}

void xuatMang(int a[][50], int m, int n)
{
	for(int i=0;i<m;i++){
		for(int j=0;j<n;j++){
			printf("%d ", a[i][j]);
		}printf("\n");
	}
}

int main()
{
	int a[50][50], b[50][50], c[50][50], d[50][50];
	int m, n;
	scanf("%d%d", &m, &n);
	int x=n, y=m;
	nhapMang(a,m,n);
	for(int i=0;i<m;i++){
		for(int j=0;j<n;j++){
			d[i][j]=a[i][j];
		}
	}
	chuyenVi(a,b,m,n,x,y);
	for(int i=0;i<m;i++){
		for(int j=0;j<y;j++){
			for(int l=0;l<n;l++){
				c[i][j]+=d[i][l]*b[l][j];
			}
		}
	}
	xuatMang(c,m,y);

return 0;
}

