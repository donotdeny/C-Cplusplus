#include<stdio.h>

void nhapMang(int a[], int m)
{
	for(int i=0;i<m;i++){
		scanf("%d", &a[i]);
	}
}

void swap(int &a, int &b)
{
	int tg=a;
	a=b;
	b=tg;
}

void xuLy(int a[], int &m, int n, int p)
{
	m+=n;
	for(int i=m;i>=p;i--){
	    a[i]=a[i-n];
	}
}

void chenMang(int a[], int b[], int m, int n, int p)
{
	for(int i=p, j=0;i<m-n,j<n;i++,j++){
		a[i]=b[j];
	}
}

void xuatMang(int a[], int m)
{
	for(int i=0;i<m;i++){
		printf("%d ", a[i]);
	}
}

int main()
{
	int m, n, p;
	scanf("%d%d%d", &m, &n, &p);
	int a[m], b[n];
	nhapMang(a,m);
	nhapMang(b,n);
	xuLy(a,m,n,p);
	chenMang(a,b,m,n,p);
	xuatMang(a,m);

return 0;
}

