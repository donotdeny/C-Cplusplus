#include<stdio.h>

void nhapMang(int arr[], int n)
{
	for(int i=0;i<n;i++){
		scanf("%d", &arr[i]);
	}
}
void xuatMang(int arr[], int n)
{
	for(int i=0;i<n;i++){
		printf("%5d", arr[i]);
	}
}
void swap(int &a, int &b)
{
	int tg=a;
	a=b;
	b=tg;
}

void sapXep(int arr[], int n)
{
	for(int i=0;i<n-1;i++){
		for(int j=i+1;j<n;j++){
			if(arr[j]<arr[i]){
				swap(arr[j],arr[i]);
			}
		}
	}
}

int main()
{
	int n;
	scanf("%d", &n);
	int arr[n];
	nhapMang(arr,n);
	xuatMang(arr,n);
	printf("\n");
	sapXep(arr,n);
	xuatMang(arr,n);

return 0;
}

