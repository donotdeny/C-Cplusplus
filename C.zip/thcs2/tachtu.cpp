#include<stdio.h>
#include<stdlib.h>
#include<string.h>

int count(char *s)
{
	int count=0;
	if(s[0]!=' ') count=1;
	for(int i=0;i<strlen(s)-1;i++){
		if(s[i]==' '&&s[i+1]!=' ') count++;
	}
	return count;
}

typedef struct{
	char str[100];
}string;

int main()
{
	char str[100];
	fgets(str, 99, stdin);
	char *p=strchr(str, '\n');
	if(p!=NULL) *p='\0';
	int n=count(str);
	string *word;
	word=(string*)malloc(n*sizeof(string));
	int i=0;
	char *token;
	token=strtok(str," ");
	while(token!=NULL){
		strcpy(word[i].str,token);
		token=strtok(NULL, " ");
		i++;
	}
	

return 0;
}

