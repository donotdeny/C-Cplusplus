#include<stdio.h>

void nhapMang(int a[], int n)
{
	for(int i=0;i<n;i++){
		scanf("%d", &a[i]);
	}
}

void xuLy(int a[], int n)
{
	for(int i=0;i<n;i++){
		int k=0;
		int count=0;
		for(int j=0;j<n;j++){
			if(a[i]==a[j]) count++;
		}
		if(count>1&&i==0) printf("%d ", a[i]);
		else {
			if(count>1){
			for(int j=0;j<i;j++){
				if(a[i]==a[j]) k=1;
			}
			if(k==1) continue;
			else printf("%d ", a[i]);
		}
		}
	}
}

int main()
{
	int a[10];
	int n;
	scanf("%d", &n);
	nhapMang(a,n);
	xuLy(a,n);
	

return 0;
}

