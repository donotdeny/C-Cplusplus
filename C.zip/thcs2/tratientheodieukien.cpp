#include<stdio.h>

int main()
{
	int n;
	scanf("%d", &n);
	if(n%100==0){
		if(n%500==0) printf("500*%d", n/500);
		else{
			int t=n%500, k=n/500;
			printf("500*%d+", k);
			if(t%200==0&&t>100) printf("200*%d", t/200);
			else{
				int l=t%200;
				if(t>200) printf("200*%d+", t/200);
				printf("100*%d", l/100);
			}
		}
	}

return 0;
}

