#include<stdio.h>

int main()
{
	int a, b;
	scanf("%d%d", &a, &b);
	int t=64;
	int c=t+b-1;
	for(int i=1;i<=a;i++){
		int k=63+i;
		for(int j=1;j<=b;j++){
			if(j>b-i) printf("%c", c);
			else {
				printf("%c", k);
				k++;
			}
		}printf("\n");
		t++;
	}

return 0;
}

