#include<stdio.h>

int main()
{
	int a, b, sum=0;
	scanf("%d %d", &a, &b);
	if(a<b){
		while(a<=b){
			sum+=a;
			a++;
		} printf("%d", sum);
	}
	else {
			if(a==b) printf("%d", a);
			else {while(b<=a){
				sum+=b;
				b++;
			}printf("%d", sum);
			}
		}

return 0;
}

