#include<stdio.h>
#include<string.h>

int count(char *s)
{
	int dem=0;
	if(s[0]!=' ') dem=1;
	for(int i=0;i<strlen(s)-1;i++){
		if(s[i]==' '&&s[i+1]!=' ') dem++;
	}
	return dem;
}

int main()
{
	char str[100];
	fgets(str, 99, stdin);
	strlwr(str);
	int n=count(str);
	int dem=1, temp, dem2=1;
	printf("%c", str[0]);
	for(int i=0;i<strlen(str);i++){
		if(str[i]==' '&&str[i+1]!=' '){
			dem++;
			if(dem==n) break;
			printf("%c", str[i+1]);
		}
	}
	for(int i=0;i<strlen(str);i++){
		if(str[i]==' '&&str[i+1]!=' ') dem2++;
		if(dem2==n){
			temp=i+1;
			break;
		}
	}
	for(int i=temp;i<strlen(str)-1;i++){
		printf("%c", str[i]);
	}
	printf("@ptit.edu.vn");

return 0;
}

