#include<stdio.h>
#include<stdbool.h>
#include<math.h>

int countNum(int n)
{
	int count=0;
	while(n>0){
		count++;
		n/=10;
	}
	return count;
}

bool armstrongNum(int n)
{
	int i;
	int m=n, sum=0;
	while(n>0){
		i=n%10;
		sum+=pow(i,countNum(m));
		n/=10;
	}if(sum==m) return true;
	return false;
}

int main()
{
	int n;
	scanf("%d", &n);
	for(int i=1;i<=n;i++){
		if(armstrongNum(i)) printf("%d ", i);
	}

return 0;
}

