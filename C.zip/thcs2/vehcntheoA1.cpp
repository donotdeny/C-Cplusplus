#include<stdio.h>

int main()
{
	int a, b;
	scanf("%d%d", &a, &b);
	if(a>=b){
	for(int i=1;i<=a;i++){
		int k=a;
		int t=a;
		for(int j=1;j<=b;j++){
			if(j<i){
				printf("%d", k);
				k--;
			}
			else {
				printf("%d", t+1-i);
			}
		}printf("\n");
	}
}
    else {
    	for(int i=1;i<=a;i++){
		int k=b;
		int t=b;
		for(int j=1;j<=b;j++){
			if(j<i){
				printf("%d", k);
				k--;
			}
			else {
				printf("%d", t+1-i);
			}
		}printf("\n");
	}
	}

return 0;
}

