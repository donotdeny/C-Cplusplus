#include<stdio.h>
#include<math.h>

void nhapMang(int arr[], int n)
{
	for(int i=0;i<n;i++){
		scanf("%d", &arr[i]);
	}
}

float ex1(int arr[], int n)
{
	int sum=0, count=0;
	for(int i=1;i<n;i+=2){
		if(arr[i]%2==1){
		++count;
		sum+=arr[i];	
		}
	}
return (float)sum/count;
}

int findMaxNum(int arr[], int n)
{
	int MAX=arr[0];
	for(int i=1;i<n;i++){
		if(arr[i]>MAX) MAX=arr[i];
	}return MAX;
}

void findMin(int arr[], int n)
{
	int MIN=arr[0];
	for(int i=1;i<n;i++){
		if(arr[i]<MIN) MIN=arr[i];
	}
	for(int i=0;i<n;i++){
		if(arr[i]==MIN) printf("\nvi tri so nho nhat trong mang la %d", i+1);
	}
}

void outSquareNum(int arr[], int n)
{
	for(int i=0;i<n;i++){
		for(int j=1;j<=sqrt(arr[i]);j++){
			if(j*j==arr[i]) printf("%d,", arr[i]);
		}
	}
}
void outPrimeNum(int arr[], int n)
{
	for(int i=0;i<n;i++){
		int count=0;
		for(int j=1;j<=arr[i];j++){
			if(arr[i]%j==0) ++count;
		} if(count==2) printf("%d,", arr[i]);
	}
}

void swapNum(int arr[], int n)
{
	for(int i=0;i<n;i++){
		if(arr[i]<0) arr[i]=0;
	}
}

void outNewArr(int arr[], int n)
{
	for(int i=0;i<n;i++){
		printf("%d,", arr[i]);
	}
}

int main()
{
	int n;
	int sum=0, count=0;
	printf("nhap vao so phan tu cua arr[n]");
	scanf("%d", &n);
	int arr[n];
	nhapMang(arr,n);
    printf("\ntrung binh cong cac so le o vi tri chan la %f", ex1(arr,n));
    printf("\nso lon nhat trong mang la %d", findMaxNum(arr,n));
    findMin(arr,n);
    printf("\ncac so chinh phuong co trong mang la :");
    outSquareNum(arr,n);
    printf("\ncac so nguyen to co trong mang la :");
    outPrimeNum(arr,n);
    printf("\nmang cac so nguyen khong am la:");
    swapNum(arr,n);
    outNewArr(arr,n);

    
return 0;
}

