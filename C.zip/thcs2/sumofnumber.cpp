#include<stdio.h>

int main()
{
	int n, sum=0;
	int i;
	scanf("%d", &n);
	while(n>0){
		i=n%10;
		sum+=i;
		n/=10;
	}
	printf("%d", sum);

return 0;
}

