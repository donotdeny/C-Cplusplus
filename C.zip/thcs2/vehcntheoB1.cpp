#include<stdio.h>

int main()
{
	int a, b;
	scanf("%d%d", &a, &b);
	for(int i=1;i<=a;i++){
		int t=i;
		for(int j=1;j<=b;j++){
			if(t<=b){
				printf("%d", t);
				t++;
			}
			else printf("%d", b);
		}printf("\n");
	}

return 0;
}

