#include<stdio.h>
#include<stdbool.h>

bool primeNum(int n)
{
	int count=0;
	for(int i=2;i<=n;i++){
		if(n%i==0) count++;
	}if(count==1) return true;
	return false;
}

int demPrimeNum(int n)
{
	int count=0;
	for(int i=2;i<n;i++){
		if(primeNum(i)) if(n%i==0) count++;
	}
	return count;
}

bool dieuKien(int n)
{
	int count=demPrimeNum(n);
	int t, k=0;
	for(int i=2;i<n;i++){
		if(primeNum(i)) {
			t=i*i;
			if(n%i==0&&n%t==0) k++;
		} 
	} if(count==k&&k!=0&&count!=0) return true;
	return false;
}

int main()
{
	int a, b;
	scanf("%d%d", &a, &b);
	if(a<b){
		for(int i=a;i<=b;i++){
			if(dieuKien(i)) printf("%d ", i);
		}
	}
	if(a>b){
		for(int i=b;i<=a;i++){
			if(dieuKien(i)) printf("%d ", i);
		}
	}

return 0;
}

