#include<stdio.h>

int main()
{
	int n;
	scanf("%d", &n);
	int tg=0;
	while(n>0){
		tg=tg*10+n%10;
		n/=10;
	}
	printf("%d", tg);

return 0;
}

