#include<stdio.h>
#include<math.h>

int main()
{
	int n;
	scanf("%d", &n);
	for(int i=1;i<=n;i++){
		for(int j=1;j<=2*n+1-2*i;j++) {
		if(j<=abs(n-i)) printf("~");
		else printf("*");
	   } printf("\n");
	} 
	int t=n-1;
	for(int i=1;i<=t;i++){
		for(int j=1;j<=2*i+1;j++){
			if(j<=i) printf("~");
			else printf("*");
		}printf("\n");
	}

return 0;
}

