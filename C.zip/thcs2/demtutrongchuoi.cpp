#include<stdio.h>
#include<string.h>
#include<stdlib.h>

int dem(char *s)
{
	int count=0;
	if(s[0]!=' ') count=1;
	for(int i=0;i<strlen(s)-1;i++){
		if(s[i]==' '&&s[i+1!=' ']) count++;
	}
	return count;
}

typedef struct{
	char str[100];
}string;

int main()
{
	int max=0;
	char str[100];
	char str1[100], str2[100];
	fgets(str, 99, stdin);
	strlwr(str);
	char *p=strchr(str,'\n');
	if(p!=NULL) *p='\0';
	strcpy(str1,str);
	strcpy(str2,str);
	string *word;
	int n=dem(str), i=0;
	word=(string*)malloc(n*sizeof(string));
	char *token, *token1, *token2;
	token=strtok(str," ");
	while(token!=NULL){
		strcpy(word[i].str,token);
		token=strtok(NULL, " ");
		i++;
	}
	token1=strtok(str1," ");
	while(token1!=NULL){
		int count=0;
		for(i=0;i<n;i++){
			if(strcmp(token1,word[i].str)==0) count++;
		}
		if(max<count) max=count;
		token1=strtok(NULL," ");
	}
	token2=strtok(str2," ");
	int max2=0;
	char temp[50];
	while(token2!=NULL){
		int count=0;
		for(i=0;i<n;i++){
			if(strcmp(token2,word[i].str)==0) count++;
		}
		if(max2<count) max2=count;
		if(max2==max){
			strcpy(temp,token2);
			break;
		}
		token2=strtok(NULL, " ");
	}
	printf("%s %d", temp, max2);

return 0;
}

