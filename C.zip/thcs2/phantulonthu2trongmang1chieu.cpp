#include<stdio.h>

void nhapMang(int a[], int n)
{
	for(int i=0;i<n;i++){
		scanf("%d", &a[i]);
	}
}

int main()
{
	int n;
	scanf("%d", &n);
	int a[n];
	nhapMang(a,n);
	int MAX=a[0], max=a[0];
	int temp;
	for(int i=1;i<n;i++){
		if(MAX<a[i]) MAX=a[i];
	}
	for(int i=1;i<n;i++){
		if(max<a[i]) {
			temp=max;
			max=a[i];
			if(max==MAX) max=temp;
		}
	}
	printf("%d %d", MAX, max);

return 0;
}

