#include<stdio.h>

void xuLy(int a[][50], int n)
{
	int gt=1, vthang=0, vtcot=0, hang=n, cot=n;
	while(gt<=n*n){
		for(int i=vtcot;i<cot;i++){
			a[vthang][i]=gt;
			gt++;
		}
		for(int i=vthang+1;i<hang;i++){
			a[i][cot-1]=gt;
			gt++;
		}
		for(int i=cot-2;i>=vtcot;i--){
			a[hang-1][i]=gt;
			gt++;
		}
		for(int i=hang-2;i>vthang;i--){
			a[i][vtcot]=gt;
			gt++;
		}
		vthang++; vtcot++; hang--; cot--;
	}
}

void xuatMang(int a[][50], int n)
{
	for(int i=0;i<n;i++){
		for(int j=0;j<n;j++){
			printf("%d ", a[i][j]);
		}printf("\n");
	}
}

int main()
{
	int a[50][50];
	int n;
	scanf("%d", &n);
	xuLy(a,n);
	xuatMang(a,n);

return 0;
}

