#include<stdio.h>

void nhapMang(int a[], int n)
{
	for(int i=0;i<n;i++){
		scanf("%d", &a[i]);
	}
}

int main()
{
	int a[50];
	int n;
	scanf("%d", &n);
	int b[n]={};
	nhapMang(a,n);
	for(int i=1;i<n;i++){
		if(a[i]==a[i-1]+1) b[i]=b[i-1]+1;
	}
	int k=0, max=0;
	for(int i=0;i<n;i++){
		if(max<b[i]){
			max=b[i];
			k=i;
		}
	}
	for(int i=k-max;i<=k;i++){
		printf("%d ", a[i]);
	}

return 0;
}

