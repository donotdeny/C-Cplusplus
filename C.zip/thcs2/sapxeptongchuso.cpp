#include<stdio.h>

int main()
{
	int a, b, x, y;
	scanf("%d %d", &a, &b);
	int c=a, d=b;
	int sum1=0, sum2=0;
	while(a>0){
		x=a%10;
		sum1+=x;
		a/=10;
	} 
	while(b>0){
		y=b%10;
		sum2+=y;
		b/=10;
	}
	if(sum1==sum2) printf("%d %d", c, d);
	else {
		if(sum1<sum2) printf("%d %d", c, d);
		else printf("%d %d", d, c);
	}

return 0;
}

