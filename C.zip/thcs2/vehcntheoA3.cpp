#include<stdio.h>

int main()
{
	int a, b, t;
	int arr[50][50];
	scanf("%d%d", &a, &b);
	for(int i=0;i<a;i++){
		a>b? t=a:t=b;
		int k=t;
		for(int j=0;j<b;j++){
			if(j>=i) arr[i][j]=t-i;
			else {
				arr[i][j]=k;
				k--;
			}
		}
	}
	for(int i=a-1;i>=0;i--){
		for(int j=0;j<b;j++){
			printf("%d", arr[i][j]);
		}printf("\n");
	}

return 0;
}

