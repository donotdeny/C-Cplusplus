#include<stdio.h>
#include<string.h>
#include<stdbool.h>

bool isSpace(char c)
{
	return c==' '|| c=='\n'|| c=='	';
}

void removeAtTail(char* line)
{
	int len=strlen(line);
	int i=len-1;
	while(isSpace(line[i])){
		line[i]='\0';
		i--;
	}
}

void removeAtHead(char* c)
{
	int len=strlen(c);
	int count=0;
	for(int i=0;i<len;i++){
		if(isSpace(c[i])) count++;
		else break;
	}
	for(int i=0;i<=len-count;i++){
		c[i]=c[i+count];
	}
}

void removeAtMid(char* c)
{
	int len=strlen(c);
	for(int i=0;i<len;i++){
		if(isSpace(c[i])&&isSpace(c[i+1])){
			for(int j=i+1;j<len;j++){
				c[j]=c[j+1];
			}
			i--;
			len--;
		}
	}
}

int main()
{
	char line[50];
	fgets(line, sizeof line, stdin);
	removeAtTail(line);
	removeAtHead(line);
	removeAtMid(line);
	puts(line);

return 0;
}

