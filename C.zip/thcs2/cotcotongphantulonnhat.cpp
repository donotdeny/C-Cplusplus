#include<stdio.h>
#define MAX 100

void nhapMang(int a[][MAX], int n)
{
	for(int i=0;i<n;i++){
		for(int j=0;j<n;j++){
			scanf("%d", &a[i][j]);
		}
	}
}

int xuLy(int a[][MAX],int n, int t)
{
	int tg, i;
	for(i=0;i<n;i++){
		int temp=0;
		for(int j=0;j<n;j++){
			temp+=a[j][i];
		}
		if(temp==t) return i;
	}
}

int sumValue(int a[][MAX], int n)
{
	int sum=0;
	for(int i=0;i<n;i++){
		sum+=a[i][0];
	}
	for(int i=1;i<n;i++){
		int tg=0;
		for(int j=0;j<n;j++){
			tg+=a[j][i];
		}
		if(sum<tg) sum=tg;
	}
	return sum;
}

int main()
{
	int a[MAX][MAX];
	int n;
	scanf("%d", &n);
	nhapMang(a,n);
	int t=sumValue(a,n);
	int k=xuLy(a,n,t);
	printf("%d\n", k+1);
	for(int i=0;i<n;i++){
		printf("%d ", a[i][k]);
	}

return 0;
}

