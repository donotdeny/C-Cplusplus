#include<stdio.h>

int main()
{
	int n, x, y;
	scanf("%d", &n);
	y=n%10;
	if(n==0) printf("0 0");
	else{ 
		while(n>0){
		x=n%10;
		n/=10;
	}
	printf("%d %d", x, y);
}
return 0;
}

