#include<stdio.h>

int main()
{
	float a, b;
	scanf("%f %f", &a, &b);
	if(a==0) {
		if(b==0) printf("VSN");
		else printf("VN");
	}
	else printf("%.2f", -b/a);

return 0;
}

