#include<stdio.h>
#include<stdbool.h>

bool ktra(int n)
{
	int i;
	while(n>0){
		i=n%10;
		if(i!=0&&i!=6&&i!=8) return false;
		n/=10;	
	}
	return true;
}

int main()
{
	int n, i;
	scanf("%d", &n);
	if(ktra(n)) printf("1");
	else printf("0");
	

return 0;
}

