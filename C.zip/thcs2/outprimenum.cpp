#include<stdio.h>
#include<stdbool.h>

bool soNguyenTo(int n)
{
	int count=0;
	for(int i=1;i<=n;i++){
		if(n%i==0) count++;
	}if(count==2) return true;
	return false;
}

int main()
{
	int n;
	scanf("%d", &n);
	for(int i=1;i<n;i++){
		if(soNguyenTo(i)) printf("%d ", i);
	}

return 0;
}

