#include<stdio.h>

void nhapMang(int a[][50], int m, int n)
{
	for(int i=0;i<m;i++){
		for(int j=0;j<n;j++){
			scanf("%d", &a[i][j]);
		}
	}
}

void xuatMang(int a[][50], int m, int n)
{
	for(int i=0;i<m;i++){
		for(int j=0;j<n;j++){
			printf("%d ", a[i][j]);
		}
		printf("\n");
	}
}

void xoaHang(int a[][50], int &m, int n, int x)
{
	for(int i=x;i<m-1;i++){
		for(int j=0;j<n;j++){
			a[i][j]=a[i+1][j];
		}
	}
	m--;
}

void xoaCot(int a[][50], int m, int &n, int y)
{
	for(int i=0;i<m;i++){
		for(int j=y;j<n-1;j++){
			a[i][j]=a[i][j+1];
		}
	}
	n--;
}

int hangCanXoa(int a[][50], int m, int n)
{
	int MAX=0;
	for(int i=0;i<n;i++){
		MAX+=a[0][i];
	}
	for(int i=1;i<n;i++){
		int sum=0;
		for(int j=0;j<n;j++){
			sum+=a[i][j];
		}
		if(MAX<sum) MAX=sum;
	}
	for(int i=0;i<n;i++){
		int temp=0;
		for(int j=0;j<n;j++){
			temp+=a[i][j];
		}
		if(temp==MAX) return i;
	}
}

int cotCanXoa(int a[][50], int m, int n){
	int MAX=0;
	for(int i=0;i<m;i++){
		MAX+=a[i][0];
	}
	for(int i=1;i<n;i++){
		int sum=0;
		for(int j=0;j<m;j++){
			sum+=a[j][i];
		}
		if(MAX<sum) MAX=sum;
	}
	for(int i=0;i<n;i++){
		int temp=0;
		for(int j=0;j<m;j++){
			temp+=a[j][i];
		}
		if(temp==MAX) return i;
	}
}

int main()
{
	int a[50][50], b[50][50];
	int m, n;
	scanf("%d%d", &m, &n);
	int c=m, d=n;
	nhapMang(a,m,n);
	for(int i=0;i<c;i++){
		for(int j=0;j<d;j++){
			b[i][j]=a[i][j];
		}
	}
	int x=hangCanXoa(a,m,n);
	xoaHang(a,m,n,x);
	int y=cotCanXoa(b,c,d);
	xoaCot(a,m,n,y);
	xuatMang(a,m,n);

return 0;
}

