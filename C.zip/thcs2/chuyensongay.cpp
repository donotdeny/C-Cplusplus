#include<stdio.h>

int main()
{
	int n, count1=0, count2=0;
	scanf("%d", &n);
	while(n>=365){
		++count1;
		n-=365;
	}
	while(n>=7){
		++count2;
		n-=7;
	}
	printf("%d %d %d", count1, count2, n);

return 0;
}

