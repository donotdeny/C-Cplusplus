#include<stdio.h>

void nhap(int a[], int n)
{
	for(int i=0;i<n;i++){
		scanf("%d", &a[i]);
	}
}

int main()
{
	int a[50], b[50];
	int n, m, p;
	scanf("%d%d", &n, &m);
	scanf("%d", &p);
	nhap(a,n);
	nhap(b,m);
	n+=m;
	for(int i=p;i<n-m;i++){
		a[i+m]=a[i];
	}
	for(int i=0;i<m;i++){
		a[i]=b[i];
	}
	for(int i=0;i<n;i++){
		printf("%d ", a[i]);
	}

return 0;
}

