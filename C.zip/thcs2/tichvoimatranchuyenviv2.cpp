#include<stdio.h>

int main()
{
	int a[50][50], b[50][50], c[50][50];
	int m, n;
	scanf("%d%d", &m, &n);
	for(int i=0;i<m;i++){
		for(int j=0;j<n;j++){
			scanf("%d", &a[i][j]);
		}
	}
	for(int i=0, x=0;i<n;i++,x++){
		for(int j=0, y=0;j<m;j++, y++){
			b[x][y]=a[j][i]; 
		}
	}
	for(int i=0;i<m;i++){
		for(int j=0;j<m;j++){
			for(int l=0;l<n;l++){
				c[i][j]+=a[i][l]*b[l][j];
			}
		}
	}
	for(int i=0;i<m;i++){
		for(int j=0;j<m;j++){
			printf("%d ", c[i][j]);
		}printf("\n");
	}

return 0;
}

