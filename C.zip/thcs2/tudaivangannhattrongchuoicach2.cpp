#include<stdio.h>
#include<string.h>
#include<stdlib.h>

int dem(char *s)
{
	int count=0;
	if(s[0]!=' ') count=1;
	for(int i=0;i<strlen(s)-1;i++){
		if(s[i]==' '&&s[i+1]!=' ') count++;
	}
	return count;
}

typedef struct{
	char str[100];
}string;

int main()
{
	char str[100];
	fgets(str, 99, stdin);
	char *p=strchr(str,'\n');
	if(p!=NULL) *p='\0';
	int n=dem(str);
	string *word;
	word=(string*)malloc(n*sizeof(string));
	char *token;
	int i=0;
	token=strtok(str," ");
	while(token!=NULL){
		strcpy(word[i].str,token);
		token=strtok(NULL," ");
		i++;
	}
	int max=-9999, min=9999, temp1, temp2;
	for(int i=0;i<n;i++){
		int k=strlen(word[i].str);
		if(max<k){
			max=k;
			temp1=i;
		}
	}
	for(int i=0;i<n;i++){
		int k=strlen(word[i].str);
		if(min>k){
			min=k;
			temp2=i;
		}
	}
	printf("%s %s", word[temp1].str, word[temp2].str);

return 0;
}

