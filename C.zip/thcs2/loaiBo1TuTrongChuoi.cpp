#include<stdio.h>
#include<string.h>

int main()
{
	char str[50];
	char word[50];
	fgets(str, sizeof str, stdin);
	//scanf("%s", word);
	gets(word);
	char *token;
	token=strtok(str," ");
	while(token!=NULL){
		if(strcmp(word,token)!=0) printf("%s ", token);
		token=strtok(NULL," ");
	}

return 0;
}

