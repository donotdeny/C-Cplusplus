#include<stdio.h>

int testThuanNghich(int n)
{
	int tg=0;
	int m=n;
	while(n>0){
		tg=tg*10+n%10;
		n/=10;
	} if(tg==m) return 1;
}

int main()
{
	for(int i=1;i<100000;i++){
		if(testThuanNghich(i)==1) printf("%d ", i);
	}

return 0;
}

