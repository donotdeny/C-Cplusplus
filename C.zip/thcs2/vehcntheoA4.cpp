#include<stdio.h>

void xuatMang(int arr[][50], int a, int b)
{
	for(int i=a-1;i>=0;i--){
		for(int j=0;j<b;j++){
			printf("%d", arr[i][j]);
		}printf("\n");
	}
}

int main()
{
	int arr[50][50];
	int a, b, t;
	scanf("%d%d", &a, &b);
	a>b? t=a:t=b;
	for(int i=0;i<a;i++){
		int k=t-i+1;
		int l=t+1-b;
		for(int j=0;j<b;j++){
			if(i<=b){
			    if(j<b-i) arr[i][j]=t-i;
			    else {
				    arr[i][j]=k;
				    k++;
			    }
		    }
		    else {
			    arr[i][j]=l;
			    l++;
		    }
		}
	}
	xuatMang(arr,a,b);

return 0;
}

