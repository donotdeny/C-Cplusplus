#include<stdio.h>
#include<stdbool.h>

bool primeNum(int n)
{
	int count=0;
	for(int i=2;i<=n;i++){
		if(n%i==0) count++;
	}if(count==1) return true;
	return false;
}

void nhapMang(int a[][50], int n)
{
	for(int i=0;i<n;i++){
		for(int j=0;j<n;j++){
			scanf("%d", &a[i][j]);
		}
	}
}

int traVe(int a[][50], int n)
{
	int count=0;
	for(int i=0;i<n;i++){
		if(primeNum(a[i][i])) count++;
	}
	for(int i=0,j=n-1;i<n,j>=0;i++,j--){
		if(primeNum(a[i][j])) count++;
	} return count;
}

void xuatMang(int a[][50], int n)
{
	for(int i=0;i<n;i++){
		for(int j=0;j<n;j++){
			printf("%d ", a[i][j]);
		}printf("\n");
	}
}

int main()
{
	int a[50][50];
	int n, k=0, dem=0;
	scanf("%d", &n);
	nhapMang(a,n);
	int t=traVe(a,n);
	int b[t];
	for(int i=0;i<n;i++){
		if(primeNum(a[i][i])) {
			b[k]=a[i][i];
			k++;
			dem++;
		}
	}
	for(int i=0,j=n-1;i<n,j>=0;i++,j--){
		if(primeNum(a[i][j])) {
			b[k]=a[i][j];
			k++;
			dem++;
		}
	}
	int count=1;
	for(int i=1;i<k;i++){
		int x=0;
		for(int j=0;j<i;j++){
			if(b[j]==b[i]) x=1;
		}
		if(x==1) continue;
		else count++;
	}
	if(dem==0) printf("0");
	else printf("%d", count);
	
return 0;
}

