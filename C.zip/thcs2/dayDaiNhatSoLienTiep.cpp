#include<stdio.h>
#include<stdbool.h>

bool dieuKien(int a, int b)
{
	if(b==a+1) return true;
	return false;
}

void nhapMang(int a[])
{
	for(int i=0;i<20;i++){
		scanf("%d", &a[i]);
	}
}

int main()
{
	int a[20];
	int count, i;
	int temp, MAX=0;
	nhapMang(a);
	for(i=0;i<20;i++){
		count=1;
		if(dieuKien(a[i],a[i+1])) {
			count++;
			for(int j=i+1;j<20;j++){
				if(dieuKien(a[j],a[j+1])) count++;
				else break;
			}
		}
		if(MAX<count) MAX=count;
	}
	for(int i=0;i<20;i++){
		count=1;
		if(dieuKien(a[i],a[i+1])) {
			count++;
			for(int j=i+1;j<20;j++){
				if(dieuKien(a[j],a[j+1])) count++;
				else break;
			}
		}
		if(count==MAX) {
			temp=i;
			break;
		}
	}
	for(int i=temp;i<temp+MAX;i++){
		printf("%d ", a[i]);
	}

return 0;
}

