#include<stdio.h>

int main()
{
	int a[2]={1,2};
	int *p=a;
	printf("%d ", p);

return 0;
}

